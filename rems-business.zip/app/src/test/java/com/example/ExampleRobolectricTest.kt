package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.BillEntity
import com.example.data.db.CustomerEntity
import com.example.data.db.TransactionEntity
import com.example.utils.JsonBackupManager
import com.example.utils.ShareAndPrintUtils
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("REMS Business", appName)
  }

  @Test
  fun `test customer based filename generation`() {
    val billFileName = ShareAndPrintUtils.generateCustomerFileName("Ramesh Kumar", "Bill", "pdf")
    assertEquals("Ramesh Kumar_Bill.pdf", billFileName)

    val receiptFileName = ShareAndPrintUtils.generateCustomerFileName("Ramesh Kumar", "Payment Receipt", "pdf")
    assertEquals("Ramesh Kumar_Payment Receipt.pdf", receiptFileName)

    val reportFileName = ShareAndPrintUtils.generateCustomerFileName("Ramesh Kumar", "Service Report", "pdf")
    assertEquals("Ramesh Kumar_Service Report.pdf", reportFileName)

    val imageFileName = ShareAndPrintUtils.generateCustomerFileName("Ramesh Kumar", "Image", "jpg")
    assertEquals("Ramesh Kumar_Image.jpg", imageFileName)
  }

  @Test
  fun `test Khata Book JSON export structure`() {
    val customers = listOf(
      CustomerEntity(id = 1, name = "Ramesh Kumar", mobile = "9876543210", address = "Ward 4")
    )
    val transactions = listOf(
      TransactionEntity(id = 10, customerId = 1, date = "22/08/2026", work = "Wiring", lene = 5000.0, aaye = 2000.0, discount = 100.0, paymentMode = "UPI", totalDelta = 2900.0)
    )

    val jsonStr = JsonBackupManager.generateKhataBookJsonString(customers, transactions)
    assertNotNull(jsonStr)

    val json = JSONObject(jsonStr)
    assertEquals("REMS_KHATA_BOOK_BACKUP", json.getString("fileType"))
    assertEquals(1, json.getInt("totalCustomers"))
    assertEquals(1, json.getInt("totalTransactions"))

    val customersArray = json.getJSONArray("customers")
    assertEquals(1, customersArray.length())
    assertEquals("Ramesh Kumar", customersArray.getJSONObject(0).getString("name"))

    val txArray = json.getJSONArray("transactions")
    assertEquals(1, txArray.length())
    assertEquals("Ramesh Kumar", txArray.getJSONObject(0).getString("customerName"))
    assertEquals(5000.0, txArray.getJSONObject(0).getDouble("lene"), 0.001)
  }

  @Test
  fun `test Bills JSON export structure`() {
    val bills = listOf(
      BillEntity(
        billNo = "ZB0001",
        date = "2026-08-22",
        customerName = "Suresh Sharma",
        customerPhone = "9812345678",
        customerAddress = "Main Bazar",
        discount = 50.0,
        totalAmount = 1550.0,
        netAmount = 1500.0,
        itemsJson = "[]"
      )
    )

    val jsonStr = JsonBackupManager.generateBillsJsonString(bills)
    assertNotNull(jsonStr)

    val json = JSONObject(jsonStr)
    assertEquals("REMS_BILLS_BACKUP", json.getString("fileType"))
    assertEquals(1, json.getInt("totalBills"))

    val billsArray = json.getJSONArray("bills")
    assertEquals(1, billsArray.length())
    assertEquals("ZB0001", billsArray.getJSONObject(0).getString("billNo"))
    assertEquals("Suresh Sharma", billsArray.getJSONObject(0).getString("customerName"))
    assertEquals(1500.0, billsArray.getJSONObject(0).getDouble("netAmount"), 0.001)
  }
}

